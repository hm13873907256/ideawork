create function getChildLst(rootId varchar(64))
  returns varchar(4000)
  BEGIN
    DECLARE sTemp VARCHAR(21845); 
    DECLARE sTempChd VARCHAR(21845); 
    SET sTemp = ''; 
    SET sTempChd =rootId; 
    WHILE sTempChd IS NOT NULL DO 
            SET sTemp = CONCAT(sTemp ,',',sTempChd); 
            SELECT GROUP_CONCAT(ZORGID) INTO sTempChd FROM mdg_hr_zorg WHERE FIND_IN_SET(ZSPORGID,sTempChd)>0; 
        END WHILE; 
        RETURN sTemp; 
    END;

