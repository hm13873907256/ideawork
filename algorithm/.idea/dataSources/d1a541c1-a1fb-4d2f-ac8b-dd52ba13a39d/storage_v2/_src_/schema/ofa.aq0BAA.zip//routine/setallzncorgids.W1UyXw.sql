create procedure setallzncorgids(IN rootId varchar(100), IN nDepth int, IN rangeId varchar(100))
  BEGIN
      DECLARE done INT DEFAULT 0;
      DECLARE b varchar(100);
      DECLARE cur1 CURSOR FOR SELECT zncorgid FROM mdg_hr_zorg where zsporgid=rootId;
      DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
		 
      insert into ofa_yb_ranges_zncorgid(sno,id,depth,range_id) values (null,rootId,nDepth,rangeId);

    
      OPEN cur1;
    
      FETCH cur1 INTO b;
      WHILE done=0 DO
              CALL setallzncorgids(b,nDepth+1,rangeId);
              FETCH cur1 INTO b;
      END WHILE;
    
      CLOSE cur1;
     END;

