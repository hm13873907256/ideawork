create procedure showalldepts(IN rootId varchar(100), IN rangeId varchar(100))
  BEGIN
      
      DELETE FROM ofa_yb_ranges_zorgid where range_id=rangeId;
			DELETE FROM ofa_yb_ranges_zncorgid where range_id=rangeId;

      CALL setallzorgids(rootId,0,rangeId);
			CALL setallzncorgids(rootId,0,rangeId);
      
     END;

